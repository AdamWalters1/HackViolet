
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Plus, LayoutDashboard, MessageSquare, Search as SearchIcon, TreePine, Sparkles, Lightbulb, X, Camera, Settings as SettingsIcon, LogOut } from 'lucide-react';
import { Plant, PlantCondition, AIChatType, PlantTargets, AppSettings, User } from './types';
import Header from './components/Header';
import PlantCard from './components/PlantCard';
import PlantDetail from './components/PlantDetail';
import AIChat from './components/AIChat';
import AddPlantModal from './components/AddPlantModal';
import IdentifyPlantModal from './components/IdentifyPlantModal';
import SettingsModal from './components/SettingsModal';
import AuthView from './components/AuthView';

const SETTINGS_BASE_KEY = 'happy_plant_settings_v3';
const FACT_DISMISS_KEY = 'happy_plant_fact_dismissed_v2';

const PLANT_FACTS = [
  "Plants really do like music! Studies show they grow faster when exposed to classical music.",
  "The Earth has more than 80,000 species of edible plants.",
  "Bamboo is the fastest-growing woody plant in the world, growing up to 35 inches per day.",
  "Sunflowers aren't just one flower. They're thousands of tiny flowers called florets.",
  "Plants can 'talk' to each other using chemical signals and underground fungal networks.",
  "Trees are the longest-living organisms on Earth; some Bristlecone pines are over 5,000 years old.",
  "The smell of cut grass is actually a plant's 'distress signal' (VOCs) released when injured.",
  "A single oak tree can support over 2,000 different species of animals, insects, and fungi.",
  "Plants have a circadian rhythm similar to humans, allowing them to 'predict' sunrise.",
  "Venus Flytraps can count! They wait for a second trigger before closing their trap to save energy.",
  "Orchids are the largest family of flowering plants, with over 25,000 different species.",
  "Strawberries are the only fruit that wear their seeds on the outside.",
  "The Baobab tree can store up to 32,000 gallons of water in its trunk to survive droughts.",
  "Some plants, like the sensitive Mimosa Pudica, actually fold their leaves when touched.",
  "Bananas are technically berries, but strawberries are not.",
  "The Titan Arum produces the world's largest unbranched flower, often smelling like rotting meat.",
  "Cactus spines are actually highly modified leaves that provide shade and protect from thirst.",
  "Ferns are ancient; they existed on Earth 200 million years before dinosaurs appeared.",
  "Chlorophyll is what makes plants green, but it also helps them convert sunlight into energy.",
  "Eucalyptus trees can grow up to 300 feet tall, making them some of the tallest plants on Earth.",
  "The world's smallest flowering plant is the Watermeal (Wolffia), which is the size of a grain of rice.",
  "Succulents store water in their leaves, stems, or roots to survive in arid environments.",
  "Plants produce oxygen through photosynthesis, which is essential for almost all life on Earth.",
  "Some trees, like the Lodgepole Pine, need the heat of a forest fire for their cones to release seeds.",
  "The Amazon Rainforest produces about 20% of the world's oxygen."
];

const DEFAULT_SETTINGS: AppSettings = {
  keeperName: 'Green Keeper',
  tempUnit: 'C',
  darkMode: false,
  notifications: {
    moistureAlerts: true,
    tempAlerts: true,
    lightAlerts: false
  },
  syncInterval: 5
};

const DEFAULT_TARGETS: PlantTargets = {
  moisture: 60,
  temperature: 22,
  light: 70,
  dailyWaterLitres: 1.5,
  dailyLightHours: 8
};

const INITIAL_PLANTS: Plant[] = [
  {
    id: 'p1',
    name: 'Monstera',
    species: 'Monstera Deliciosa',
    description: 'The Swiss Cheese Plant uses leaf fenestrations to allow light through to lower leaves.',
    image: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?q=80&w=800&auto=format&fit=crop',
    addedAt: Date.now() - 86400000 * 30,
    conditions: Array.from({length: 12}).map((_, i) => ({ 
      timestamp: Date.now() - (12-i) * 300000, 
      moisture: 60 + Math.random() * 10, 
      temperature: 22 + Math.random() * 2, 
      light: 70 + Math.random() * 5 
    })),
    targets: { ...DEFAULT_TARGETS, moisture: 65, dailyWaterLitres: 2.0, dailyLightHours: 10 }
  }
];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [plants, setPlants] = useState<Plant[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPlantId, setSelectedPlantId] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'dashboard' | 'chat'>('dashboard');
  const [isLoaded, setIsLoaded] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isIdentifyModalOpen, setIsIdentifyModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [chatInitialInput, setChatInitialInput] = useState('');
  const [isFactVisible, setIsFactVisible] = useState(true);

  // Robust daily hash that refreshes if the date changes
  const factOfTheDayHash = useMemo(() => {
    const today = new Date();
    return `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
  }, []);

  const USER_DATA_KEY = useMemo(() => currentUser ? `happy_plant_data_${currentUser.id}` : '', [currentUser]);
  const USER_SETTINGS_KEY = useMemo(() => currentUser ? `${SETTINGS_BASE_KEY}_${currentUser.id}` : '', [currentUser]);

  useEffect(() => {
    const savedSession = localStorage.getItem('happy_plant_session');
    if (savedSession) {
      setCurrentUser(JSON.parse(savedSession));
    }
  }, []);

  useEffect(() => {
    if (!currentUser) return;

    const savedPlants = localStorage.getItem(USER_DATA_KEY);
    const savedSettings = localStorage.getItem(USER_SETTINGS_KEY);
    
    if (savedPlants) {
      setPlants(JSON.parse(savedPlants));
    } else {
      setPlants(INITIAL_PLANTS);
    }

    if (savedSettings) {
      setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(savedSettings) });
    }

    const dismissedDate = localStorage.getItem(FACT_DISMISS_KEY);
    if (dismissedDate === factOfTheDayHash) {
      setIsFactVisible(false);
    } else {
      setIsFactVisible(true);
    }

    setIsLoaded(true);
  }, [currentUser, factOfTheDayHash, USER_DATA_KEY, USER_SETTINGS_KEY]);

  useEffect(() => {
    if (settings.darkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [settings.darkMode]);

  useEffect(() => {
    if (isLoaded && currentUser) {
      localStorage.setItem(USER_DATA_KEY, JSON.stringify(plants));
      localStorage.setItem(USER_SETTINGS_KEY, JSON.stringify(settings));
    }
  }, [plants, settings, isLoaded, currentUser, USER_DATA_KEY, USER_SETTINGS_KEY]);

  useEffect(() => {
    if (!currentUser) return;
    const interval = setInterval(() => {
      setPlants(prev => prev.map(p => {
        const last = p.conditions[p.conditions.length - 1];
        const next: PlantCondition = {
          timestamp: Date.now(),
          moisture: Math.max(0, Math.min(100, (last?.moisture || 50) + (Math.random() - 0.5) * 4)),
          temperature: Math.max(10, Math.min(40, (last?.temperature || 22) + (Math.random() - 0.5) * 1)),
          light: Math.max(0, Math.min(100, (last?.light || 50) + (Math.random() - 0.5) * 8)),
        };
        return { ...p, conditions: [...p.conditions.slice(-49), next] };
      }));
    }, settings.syncInterval * 60 * 1000); 
    return () => clearInterval(interval);
  }, [settings.syncInterval, currentUser]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('happy_plant_session', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setPlants([]);
    setIsLoaded(false);
    localStorage.removeItem('happy_plant_session');
  };

  const toggleDarkMode = () => setSettings(prev => ({ ...prev, darkMode: !prev.darkMode }));

  const filteredPlants = useMemo(() => {
    if (!searchQuery.trim()) return plants;
    const q = searchQuery.toLowerCase();
    return plants.filter(p => p.name.toLowerCase().includes(q) || p.species.toLowerCase().includes(q));
  }, [plants, searchQuery]);

  const selectedPlant = useMemo(() => plants.find(p => p.id === selectedPlantId), [plants, selectedPlantId]);

  const factOfTheDay = useMemo(() => {
    let hash = 0;
    for (let i = 0; i < factOfTheDayHash.length; i++) hash = factOfTheDayHash.charCodeAt(i) + ((hash << 5) - hash);
    return PLANT_FACTS[Math.abs(hash) % PLANT_FACTS.length];
  }, [factOfTheDayHash]);

  if (!currentUser) {
    return <AuthView onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#f8fafc] dark:bg-slate-950 transition-colors duration-700">
      
      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 md:translate-x-0 md:static md:w-28 lg:w-72 md:h-screen z-50 px-4 md:px-6 md:py-8 flex flex-row md:flex-col items-center">
        <div className="w-full h-16 md:h-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl border border-white dark:border-white/5 shadow-2xl rounded-[2.5rem] flex md:flex-col items-center justify-between p-2 md:p-6 lg:p-8">
          
          <div className="hidden lg:flex items-center gap-4 mb-10 w-full px-4">
            <div className="p-3 bg-primary-gradient rounded-2xl shadow-xl shadow-emerald-500/20 rotate-3">
              <TreePine className="text-white w-6 h-6" />
            </div>
            <span className="text-2xl font-black text-slate-800 dark:text-white tracking-tight">HappyPlant</span>
          </div>

          <div className="flex flex-row md:flex-col items-center gap-2 md:gap-4 w-full md:flex-1">
            <NavBtn active={currentView === 'dashboard'} onClick={() => {setCurrentView('dashboard'); setSelectedPlantId(null);}}>
              <LayoutDashboard className="w-5 h-5 md:w-6 md:h-6" />
              <span className="hidden lg:inline text-sm font-black ml-4">Garden</span>
            </NavBtn>
            <NavBtn active={currentView === 'chat'} onClick={() => {setCurrentView('chat'); setChatInitialInput('');}}>
              <MessageSquare className="w-5 h-5 md:w-6 md:h-6" />
              <span className="hidden lg:inline text-sm font-black ml-4">Ask AI</span>
            </NavBtn>
          </div>

          <div className="flex flex-row md:flex-col items-center gap-2 md:gap-4 ml-4 md:ml-0 md:mt-10">
            <ActionBtn onClick={() => setIsIdentifyModalOpen(true)} grad="bg-amber-gradient">
              <Camera className="w-5 h-5 md:w-6 md:h-6" />
              <span className="hidden lg:inline ml-4 font-black text-[10px] uppercase tracking-widest">Identify</span>
            </ActionBtn>
            <ActionBtn onClick={() => setIsAddModalOpen(true)} grad="bg-primary-gradient">
              <Plus className="w-5 h-5 md:w-6 md:h-6" />
              <span className="hidden lg:inline ml-4 font-black text-[10px] uppercase tracking-widest">New Plant</span>
            </ActionBtn>
            <button 
              onClick={handleLogout}
              className="lg:hidden p-3 text-slate-400 hover:text-rose-500 dark:hover:text-rose-400 transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <Header 
          plants={plants} 
          settings={settings}
          user={currentUser}
          searchQuery={searchQuery} 
          onSearchChange={setSearchQuery} 
          onSettingsClick={() => setIsSettingsModalOpen(true)}
          onToggleDarkMode={toggleDarkMode}
          onLogout={handleLogout}
        />
        
        <div className="flex-1 overflow-y-auto px-6 lg:px-12 py-10">
          <div className="max-w-7xl mx-auto space-y-12">
            {currentView === 'dashboard' ? (
              selectedPlant ? (
                <PlantDetail 
                  plant={selectedPlant} 
                  onBack={() => setSelectedPlantId(null)} 
                  onDelete={() => {
                    setPlants(prev => prev.filter(p => p.id !== selectedPlantId));
                    setSelectedPlantId(null);
                  }}
                  onViewCareGuide={(q) => { setChatInitialInput(q); setCurrentView('chat'); }}
                  onUpdateImage={(img) => setPlants(prev => prev.map(p => p.id === selectedPlant.id ? {...p, image: img} : p))}
                />
              ) : (
                <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
                  
                  {!searchQuery && isFactVisible && (
                    <div className="relative p-8 rounded-[3rem] bg-white dark:bg-slate-900 shadow-2xl border border-white dark:border-white/5 flex items-center gap-8 overflow-hidden group">
                      <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/10 blur-[100px] rounded-full"></div>
                      <div className="relative z-10 w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-2xl flex items-center justify-center shrink-0">
                        <Lightbulb className="w-8 h-8 text-amber-500 group-hover:scale-110 transition-transform" />
                      </div>
                      <div className="relative z-10 flex-1">
                        <p className="text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-1">Botanical Wisdom</p>
                        <p className="text-lg font-bold text-slate-800 dark:text-slate-200 leading-snug">"{factOfTheDay}"</p>
                      </div>
                      <button onClick={() => { setIsFactVisible(false); localStorage.setItem(FACT_DISMISS_KEY, factOfTheDayHash); }} className="relative z-10 p-2 text-slate-300 hover:text-slate-500 dark:hover:text-slate-100 transition-colors">
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  )}

                  <div className="flex flex-col gap-2">
                    <h2 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight">
                      Welcome, {currentUser.name}
                    </h2>
                    <p className="text-slate-500 dark:text-slate-400 font-bold">
                      {searchQuery ? `Refining ${filteredPlants.length} matches...` : `${plants.length} plant companions healthy.`}
                    </p>
                  </div>

                  {filteredPlants.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                      {filteredPlants.map(plant => (
                        <PlantCard 
                          key={plant.id} 
                          plant={plant} 
                          onClick={() => setSelectedPlantId(plant.id)} 
                          onUpdateImage={(img) => setPlants(prev => prev.map(p => p.id === plant.id ? {...p, image: img} : p))}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="py-24 text-center bg-white dark:bg-slate-900 rounded-[4rem] border border-slate-100 dark:border-white/5 shadow-inner">
                      <div className="w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-3xl flex items-center justify-center mx-auto mb-6 text-slate-200 dark:text-slate-700">
                        <SearchIcon className="w-10 h-10" />
                      </div>
                      <h3 className="text-xl font-black text-slate-800 dark:text-white mb-2">No botanical matches</h3>
                      <p className="text-slate-400 dark:text-slate-500 max-w-xs mx-auto mb-8 font-medium">We couldn't find any plants matching your search. Try a different name.</p>
                      <button onClick={() => setSearchQuery('')} className="px-8 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-slate-200 transition-all">Clear Search</button>
                    </div>
                  )}
                </div>
              )
            ) : (
              <AIChat plants={plants} initialInput={chatInitialInput} />
            )}
          </div>
        </div>
      </main>

      {isAddModalOpen && <AddPlantModal onClose={() => setIsAddModalOpen(false)} onSubmit={(data) => {
        const id = Math.random().toString(36).substr(2, 9);
        const { name, moisture, temperature, light, targets: aiTargets, species, description, image } = data;
        
        const newPlant: Plant = {
          id,
          name,
          species: species || 'Botanical Companion',
          description: description,
          image: image || 'https://images.unsplash.com/photo-1485955900006-10f4d324d445?q=80&w=800&auto=format&fit=crop',
          addedAt: Date.now(),
          conditions: [{ timestamp: Date.now(), moisture, temperature, light }],
          targets: { ...DEFAULT_TARGETS, ...aiTargets }
        };
        setPlants(prev => [newPlant, ...prev]);
        setSelectedPlantId(id);
        setIsAddModalOpen(false);
      }} />}

      {isIdentifyModalOpen && <IdentifyPlantModal onClose={() => setIsIdentifyModalOpen(false)} onAddPlant={(data) => {
        const id = Math.random().toString(36).substr(2, 9);
        const { commonName, moisture, temperature, light, targets: aiTargets, species, description, image } = data;

        const newPlant: Plant = { 
          id, 
          name: commonName || 'Vision Plant',
          species: species || 'Identified Species',
          description: description, 
          image: image || 'https://images.unsplash.com/photo-1485955900006-10f4d324d445?q=80&w=800&auto=format&fit=crop',
          addedAt: Date.now(), 
          conditions: [{ timestamp: Date.now(), moisture: moisture || 50, temperature: temperature || 22, light: light || 50 }], 
          targets: { ...DEFAULT_TARGETS, ...aiTargets } 
        };
        setPlants(prev => [newPlant, ...prev]);
        setSelectedPlantId(id);
        setIsIdentifyModalOpen(false);
      }} />}

      {isSettingsModalOpen && <SettingsModal settings={settings} onClose={() => setIsSettingsModalOpen(false)} onSave={setSettings} onReset={() => { setPlants(INITIAL_PLANTS); setSettings(DEFAULT_SETTINGS); setIsSettingsModalOpen(false); }} />}
    </div>
  );
};

const NavBtn: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
  <button
    onClick={onClick}
    className={`flex items-center justify-center lg:justify-start w-12 h-12 lg:w-full lg:h-14 lg:px-6 rounded-2xl transition-all relative ${
      active 
        ? 'text-emerald-500 bg-emerald-500/10 dark:bg-emerald-500/20' 
        : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
    }`}
  >
    {children}
  </button>
);

const ActionBtn: React.FC<{ onClick: () => void; grad: string; children: React.ReactNode }> = ({ onClick, grad, children }) => (
  <button
    onClick={onClick}
    className={`flex items-center justify-center lg:justify-start w-12 h-12 lg:w-full lg:h-14 lg:px-6 rounded-2xl text-white shadow-xl transition-all ${grad} hover:scale-105 active:scale-95`}
  >
    {children}
  </button>
);

export default App;
