
import { GoogleGenAI, Type } from "@google/genai";
import { AIChatType, DiagnosisResult } from "../types";

const SYSTEM_CONTROLLER_PROMPT = `You are an AI controller for a smart IoT plant-watering system.
Your job is to evaluate plant sensor data and determine:
1. The plant’s happiness state: Happy, Neutral, or Unhappy.

MOOD LOGIC:
- If the average fulfillment of watering and sunlight targets is below 33%, the mood is "Unhappy".
- If it is between 34% and 67%, the mood is "Neutral".
- If it is above 67%, the mood is "Happy".

You must return ONLY valid JSON in the following format:
{
"mood": "Happy | Neutral | Unhappy",
"water_now": true | false,
"seconds": number,
"reason": "short human explanation",
"confidence": number between 0 and 1
}

Ensure the "reason" reflects the logic applied.`;

export const callGeminiAI = async (
  prompt: string,
  type: AIChatType,
  location?: { lat: number; lng: number }
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  switch (type) {
    case 'FAST':
      return await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: 'You are an expert botanist giving concise, fast advice to plant owners. Focus on immediate clarity.'
        }
      });

    case 'THINKING':
      return await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingBudget: 24576 },
          systemInstruction: 'You are a master botanical scientist. Provide deep, reasoned analysis of complex plant diseases or specific environmental growth factors.'
        }
      });

    case 'SEARCH':
      return await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          systemInstruction: `You are a professional horticulturist. Use Google Search to provide a HIGHLY STRUCTURED care guide.
          The response MUST use this exact Markdown structure for clarity:
          
          ## 🌿 Botanical Overview
          [Brief summary of the plant's origin and general hardiness]

          ### 💧 Watering Requirements
          [Specific frequency, signs of over/under watering, and seasonal adjustments]

          ### ☀️ Light & Placement
          [Ideal Lux levels or light types - e.g. "bright indirect", duration, and room placement tips]

          ### 🧪 Soil & Fertilization
          [Preferred pH, soil drainage characteristics, and N-P-K feeding schedule]

          ### ✂️ Maintenance & Troubleshooting
          [Pruning tips, common pests (like spider mites), and humidity needs]`
        }
      });

    case 'MAPS':
      return await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: location ? { latitude: location.lat, longitude: location.lng } : undefined
            }
          },
          systemInstruction: 'Locate the best rated local nurseries, botanical specialists, or garden supply stores based on user location.'
        }
      });
  }
};

export const identifyPlantFromImage = async (base64Image: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64Image.split(',')[1],
    },
  };

  const prompt = `Identify this plant. 
  Return ONLY a JSON object with this exact structure:
  {
    "species": "Scientific Name",
    "commonName": "Common Name",
    "description": "Short 1-sentence bio",
    "targets": {
      "moisture": 0-100,
      "temperature": degrees in Celsius,
      "light": 0-100,
      "dailyWaterLitres": float,
      "dailyLightHours": integer
    }
  }`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: { parts: [imagePart, { text: prompt }] },
    config: {
      responseMimeType: 'application/json'
    }
  });

  return JSON.parse(response.text || '{}');
};

export const enrichPlantData = async (name: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `The user is adding a plant named "${name}". 
  Identify the most likely plant species this refers to and provide its botanical needs.
  Also, provide a single, highly specific keyword for finding a professional botanical photograph of this exact species (e.g., "pothos" or "aloevera").
  Return ONLY a JSON object with this exact structure:
  {
    "species": "Scientific Name",
    "description": "Short 1-sentence bio",
    "unsplashKeyword": "single-word-keyword",
    "targets": {
      "moisture": 0-100,
      "temperature": degrees in Celsius,
      "light": 0-100,
      "dailyWaterLitres": float,
      "dailyLightHours": integer
    }
  }`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json'
    }
  });

  return JSON.parse(response.text || '{}');
};

export const getSmartDiagnosis = async (moisture: number, temp: number, light: number): Promise<DiagnosisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Evaluate current sensor data:
  - Moisture: ${moisture}%
  - Temperature: ${temp}°C
  - Light: ${light}%`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_CONTROLLER_PROMPT,
      responseMimeType: 'application/json'
    }
  });

  try {
    const rawText = response.text || '{}';
    return JSON.parse(rawText);
  } catch (e) {
    console.error("AI Response was not valid JSON", response.text);
    return {
      mood: 'Neutral',
      water_now: false,
      seconds: 0,
      reason: 'Diagnosis system offline.',
      confidence: 0
    };
  }
};
