
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, Bell, Clock, Droplets, X, Settings, Moon, Sun, User as UserIcon, LogOut } from 'lucide-react';
import { Plant, AppSettings, User } from '../types';
import { getHealthData } from './PlantCard';

interface HeaderProps {
  plants: Plant[];
  settings: AppSettings;
  user: User;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSettingsClick: () => void;
  onToggleDarkMode: () => void;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ plants, settings, user, searchQuery, onSearchChange, onSettingsClick, onToggleDarkMode, onLogout }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const latestUpdates = useMemo(() => {
    return plants
      .map(plant => {
        const last = plant.conditions[plant.conditions.length - 1];
        const health = getHealthData(plant);
        return {
          plantName: plant.name,
          timestamp: last?.timestamp || 0,
          mood: health.mood,
          bg: health.gradient
        };
      })
      .filter(u => u.timestamp > 0)
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, 5);
  }, [plants]);

  return (
    <header className="sticky top-0 z-40 bg-white/50 dark:bg-slate-950/50 backdrop-blur-2xl px-6 lg:px-12 py-6 flex items-center justify-between transition-all duration-500">
      
      <div className="flex-1 max-w-xl">
        <div className="relative group">
          <Search className={`absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 transition-all duration-300 ${searchQuery ? 'text-emerald-500' : 'text-slate-400 group-focus-within:text-emerald-500'}`} />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search your botanical collection..." 
            className="w-full pl-14 pr-12 py-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-white/5 rounded-3xl text-sm font-bold focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-500/20 outline-none transition-all placeholder:text-slate-400 dark:text-slate-500 shadow-sm"
          />
          {searchQuery && (
            <button 
              onClick={() => onSearchChange('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-slate-300 hover:text-slate-600 dark:hover:text-slate-100 transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
      
      <div className="flex items-center space-x-2 md:space-x-4 ml-8">
        
        <button 
          onClick={onToggleDarkMode}
          className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-white/5 text-slate-400 hover:text-slate-800 dark:hover:text-white transition-all shadow-sm active:scale-90"
        >
          {settings.darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-600" />}
        </button>

        <div className="relative" ref={notificationRef}>
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className={`p-3 rounded-2xl border transition-all shadow-sm active:scale-90 relative ${
              showNotifications ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-white/5 text-slate-400'
            }`}
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-slate-900"></span>
          </button>

          {showNotifications && (
            <div className="absolute right-0 top-full mt-4 w-80 bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-white/5 overflow-hidden animate-in fade-in zoom-in-95 duration-300 origin-top-right">
              <div className="p-6 bg-slate-50/50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-white/5">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Live Activity Feed</h3>
              </div>
              
              <div className="max-h-[350px] overflow-y-auto">
                {latestUpdates.length > 0 ? (
                  latestUpdates.map((update, i) => (
                    <div key={i} className="p-5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors border-b border-slate-50 dark:border-white/5 last:border-0 flex gap-4 items-center">
                      <div className={`w-12 h-12 rounded-2xl ${update.bg} flex items-center justify-center shrink-0 shadow-lg`}>
                        <span className="text-2xl">{update.mood}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-black text-slate-800 dark:text-slate-100 truncate">{update.plantName}</p>
                        <div className="flex items-center mt-1 text-[10px] font-bold text-slate-400">
                          <Clock className="w-3 h-3 mr-1" />
                          {new Date(update.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-10 text-center">
                    <p className="text-xs font-bold text-slate-400">No activity recorded today.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="h-8 w-px bg-slate-100 dark:bg-white/5 mx-2"></div>

        <div className="relative" ref={userMenuRef}>
          <button 
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center space-x-3 p-1.5 pr-4 rounded-full bg-white dark:bg-slate-900 border border-slate-100 dark:border-white/5 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="w-10 h-10 rounded-full bg-primary-gradient flex items-center justify-center text-xl shadow-xl group-hover:rotate-12 transition-transform">
              {user.avatar}
            </div>
            <div className="hidden lg:block text-left">
              <p className="text-[11px] font-black text-slate-800 dark:text-slate-100 leading-none">{user.name}</p>
              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mt-1">Guardian</p>
            </div>
          </button>

          {showUserMenu && (
            <div className="absolute right-0 top-full mt-4 w-64 bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl border border-slate-100 dark:border-white/5 overflow-hidden animate-in fade-in zoom-in-95 duration-300 origin-top-right">
              <div className="p-4 border-b border-slate-50 dark:border-white/5">
                <button 
                  onClick={onSettingsClick}
                  className="w-full flex items-center px-4 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-300"
                >
                  <Settings className="w-4 h-4 mr-3" />
                  <span className="text-xs font-black uppercase tracking-widest">Settings</span>
                </button>
                <button 
                  onClick={onLogout}
                  className="w-full flex items-center px-4 py-3 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-900/10 transition-colors text-rose-500"
                >
                  <LogOut className="w-4 h-4 mr-3" />
                  <span className="text-xs font-black uppercase tracking-widest">Sign Out</span>
                </button>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-900/50">
                <p className="text-[8px] font-black uppercase tracking-widest text-slate-400 text-center">
                  Logged in as<br/>{user.email}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
