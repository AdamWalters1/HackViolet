
import React, { useState, useMemo, useRef } from 'react';
import { ArrowLeft, Trash2, Calendar, Droplets, Thermometer, Sun, TreePine, BookOpen, Sparkles, AlertCircle, X, CheckCircle2, AlertTriangle, Camera, Globe2, ShieldAlert, Zap, Heart, Cpu, Play, Loader2, LineChart as ChartIcon, Activity } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Legend } from 'recharts';
import { Plant, DiagnosisResult } from '../types';
import { getHealthData } from './PlantCard';
import { getSmartDiagnosis } from '../services/geminiService';

interface PlantDetailProps {
  plant: Plant;
  onBack: () => void;
  onDelete: () => void;
  onViewCareGuide: (query: string) => void;
  onUpdateImage: (newImage: string) => void;
}

const SPECIES_KNOWLEDGE_DB: Record<string, { bio: string; proTip: string; safety: string; toxicity: 'Safe' | 'Toxic' | 'Caution' }> = {
  'Monstera Deliciosa': {
    bio: "The Swiss Cheese Plant uses leaf fenestrations to allow light through to lower leaves.",
    proTip: "If aerial roots get too long, tuck them into the soil for extra nutrients.",
    safety: "Insoluble oxalates. Keep away from curious pets.",
    toxicity: 'Toxic'
  },
  'Snake Plant': {
    bio: "Dracaena trifasciata can survive weeks of neglect and low light conditions.",
    proTip: "Wait for the soil to be completely dry before watering again.",
    safety: "Mildly toxic. Best placed on high shelves.",
    toxicity: 'Caution'
  },
  'Default': {
    bio: "This botanical companion thrives with consistent monitoring and loving care.",
    proTip: "Keep leaves clean to maximize photosynthetic efficiency.",
    safety: "Observe standard precautions with pets.",
    toxicity: 'Safe'
  }
};

const CustomChartTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl p-6 rounded-[2.5rem] shadow-2xl border border-white dark:border-white/5 min-w-[220px]">
        <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-50 dark:border-slate-800">
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{payload[0].payload.time}</span>
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-rose-500"></div>
            </div>
        </div>
        <div className="space-y-4">
            {payload.map((item: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center">
                    <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full mr-3 shadow-inner" style={{ backgroundColor: item.color }}></div>
                        <span className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">{item.name}</span>
                    </div>
                    <span className="text-sm font-black text-slate-800 dark:text-white">
                        {Math.round(item.value)}{item.name === 'Temperature' ? '°C' : '%'}
                    </span>
                </div>
            ))}
        </div>
      </div>
    );
  }
  return null;
};

const PlantDetail: React.FC<PlantDetailProps> = ({ plant, onBack, onDelete, onViewCareGuide, onUpdateImage }) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosis, setDiagnosis] = useState<DiagnosisResult | null>(null);
  const [isWatering, setIsWatering] = useState(false);
  const [imgError, setImgError] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Refined knowledge mapping
  const knowledge = useMemo(() => {
    const dbMatch = SPECIES_KNOWLEDGE_DB[plant.species] || SPECIES_KNOWLEDGE_DB['Default'];
    return {
      bio: plant.description || dbMatch.bio,
      proTip: dbMatch.proTip,
      safety: dbMatch.safety,
      toxicity: dbMatch.toxicity
    };
  }, [plant.species, plant.description]);

  const chartData = useMemo(() => {
    return plant.conditions.map((c, index) => ({
      ...c,
      interval: index + 1,
      time: new Date(c.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }));
  }, [plant.conditions]);

  const hasEnoughData = plant.conditions.length >= 3;
  const latest = plant.conditions[plant.conditions.length - 1];
  const { score, mood, label, gradient } = getHealthData(plant);

  const stats = useMemo(() => {
    if (!plant.targets) return null;
    const moistureValue = latest?.moisture || 0;
    const waterPercent = Math.min(100, Math.max(0, 100 - Math.abs(moistureValue - plant.targets.moisture) * 2));
    
    const avgLight = plant.conditions.reduce((acc, c) => acc + c.light, 0) / (plant.conditions.length || 1);
    const lightPercent = Math.min(100, Math.max(0, 100 - Math.abs(avgLight - plant.targets.light) * 2));

    return {
      water: { percent: waterPercent, target: plant.targets.moisture },
      light: { percent: lightPercent, target: plant.targets.light }
    };
  }, [plant, latest]);

  const runDiagnosis = async () => {
    if (!latest) return;
    setIsDiagnosing(true);
    try {
      const result = await getSmartDiagnosis(latest.moisture, latest.temperature, latest.light);
      setDiagnosis(result);
    } catch (err) {
      console.error("Diagnosis failed", err);
    } finally {
      setIsDiagnosing(false);
    }
  };

  const handleWater = () => {
    setIsWatering(true);
    setTimeout(() => {
      setIsWatering(false);
      setDiagnosis(null);
    }, (diagnosis?.seconds || 5) * 1000);
  };

  const displayImage = imgError 
    ? "https://images.unsplash.com/photo-1520302630444-4267ebb97262?auto=format&fit=crop&q=80&w=800" 
    : plant.image;

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-1000 pb-32">
      
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="group flex items-center bg-white dark:bg-slate-900 px-6 py-4 rounded-[1.5rem] shadow-xl border border-white dark:border-white/5 hover:-translate-x-1 transition-all">
          <ArrowLeft className="w-5 h-5 mr-3 text-emerald-500" />
          <span className="font-black text-slate-600 dark:text-slate-300 uppercase tracking-widest text-[10px]">Return to Garden</span>
        </button>
        <button 
          onClick={() => setShowDeleteConfirm(true)} 
          className="p-4 bg-white dark:bg-slate-900 text-slate-300 hover:text-rose-500 rounded-2xl shadow-xl border border-white dark:border-white/5 transition-all active:scale-90"
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-12 items-start">
        {/* Left Hero Card */}
        <div className="w-full lg:w-[450px] shrink-0 lg:sticky lg:top-32">
          <div className="bg-white dark:bg-slate-900 rounded-[4rem] p-8 shadow-2xl border border-white dark:border-white/5 overflow-hidden group">
            <div className="relative rounded-[3rem] overflow-hidden shadow-3xl mb-12 aspect-[4/5] bg-slate-100 dark:bg-slate-800">
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" capture="environment" onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  const r = new FileReader();
                  r.onloadend = () => onUpdateImage(r.result as string);
                  r.readAsDataURL(f);
                }
              }} />
              <img 
                src={displayImage} 
                alt={plant.name} 
                onError={() => setImgError(true)}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
              
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute top-6 right-6 p-4 bg-white/20 backdrop-blur-xl rounded-2xl border border-white/30 text-white opacity-0 group-hover:opacity-100 transition-all shadow-2xl"
              >
                <Camera className="w-6 h-6" />
              </button>

              <div className="absolute bottom-10 left-10 text-white pr-10">
                  <div className={`inline-flex px-5 py-2 ${gradient} rounded-2xl mb-4 shadow-2xl`}>
                      <span className="text-xs font-black uppercase tracking-widest">{mood} {label} • {score}% Health</span>
                  </div>
                  <h1 className="text-4xl md:text-5xl font-black block tracking-tight leading-tight truncate">{plant.name}</h1>
                  <p className="text-sm font-bold opacity-60 mt-2 uppercase tracking-widest">{plant.species}</p>
              </div>
            </div>

            <div className="space-y-4 mb-10">
                <StatPlate icon={Droplets} label="Moisture" value={`${Math.round(latest?.moisture || 0)}%`} color="text-emerald-500" bgColor="bg-emerald-500/10" />
                <StatPlate icon={Thermometer} label="Temp" value={`${Math.round(latest?.temperature || 0)}°C`} color="text-rose-500" bgColor="bg-rose-500/10" />
                <StatPlate icon={Sun} label="Sun" value={`${Math.round(latest?.light || 0)}%`} color="text-amber-500" bgColor="bg-amber-500/10" />
            </div>
            
            <button 
              onClick={() => onViewCareGuide(`Detailed care guide for ${plant.species}`)}
              className="w-full gradient-btn py-6 rounded-[2.5rem] font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-3"
            >
              <BookOpen className="w-4 h-4" /> Full Care Manual
            </button>
          </div>
        </div>

        {/* Right Dashboard Content */}
        <div className="flex-1 space-y-12 w-full">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <KnowledgeCard icon={Globe2} label="Botanical Origin" content={knowledge.bio} />
            <KnowledgeCard icon={Zap} label="Growth Protocol" content={knowledge.proTip} />
            <KnowledgeCard icon={ShieldAlert} label="Safety Notice" content={knowledge.safety} highlight={knowledge.toxicity !== 'Safe'} />
          </div>

          {/* Smart AI Controller Section */}
          <div className="bg-slate-950 p-10 rounded-[4rem] shadow-3xl border border-white/10 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 blur-[100px] rounded-full"></div>
            
            <div className="flex items-center justify-between mb-10 relative z-10">
               <div className="flex items-center gap-4">
                  <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 text-emerald-400">
                     <Cpu className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white tracking-tight">AI Smart Controller</h3>
                    <p className="text-[10px] font-black uppercase tracking-widest text-emerald-500/60">IoT Performance Analysis</p>
                  </div>
               </div>
               {!diagnosis && !isDiagnosing && (
                 <button 
                  onClick={runDiagnosis}
                  className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-white font-black text-[10px] uppercase tracking-widest transition-all"
                 >
                   Run Diagnosis
                 </button>
               )}
            </div>

            <div className="min-h-[160px] flex items-center justify-center">
              {isDiagnosing ? (
                 <div className="flex flex-col items-center justify-center text-center animate-in fade-in duration-500">
                    <div className="relative mb-6">
                      <div className="absolute inset-0 bg-emerald-500/20 blur-2xl animate-pulse"></div>
                      <Loader2 className="w-12 h-12 text-emerald-500 animate-spin relative" />
                    </div>
                    <p className="text-emerald-500 font-black uppercase tracking-[0.2em] text-xs">Consulting Neural Engine...</p>
                 </div>
              ) : diagnosis ? (
                 <div className="w-full space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-4">
                          <div className="flex items-center justify-between">
                             <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Calculated Sentiment</span>
                             <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                                diagnosis.mood === 'Happy' ? 'bg-emerald-500/10 text-emerald-400' :
                                diagnosis.mood === 'Neutral' ? 'bg-amber-500/10 text-amber-400' : 'bg-rose-500/10 text-rose-400'
                             }`}>
                                {diagnosis.mood}
                             </span>
                          </div>
                          <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                             <p className="text-sm font-bold text-slate-300 leading-relaxed italic">
                                "{diagnosis.reason}"
                             </p>
                          </div>
                       </div>
                       
                       <div className="flex flex-col justify-center gap-6">
                          <div className="space-y-2">
                             <div className="flex justify-between items-center text-[10px] font-black text-slate-500 uppercase tracking-widest">
                                <span>Confidence Index</span>
                                <span>{Math.round(diagnosis.confidence * 100)}%</span>
                             </div>
                             <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                                <div className="h-full bg-primary-gradient rounded-full" style={{ width: `${diagnosis.confidence * 100}%` }}></div>
                             </div>
                          </div>

                          <div className="flex items-center gap-4">
                             <div className={`flex-1 p-6 rounded-3xl border flex items-center justify-between ${
                                diagnosis.water_now ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-white/5 border-white/5 text-slate-500'
                             }`}>
                                <div>
                                   <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Recommendation</p>
                                   <p className="text-lg font-black">{diagnosis.water_now ? 'Water Now' : 'Standby'}</p>
                                </div>
                                {diagnosis.water_now && <div className="text-2xl font-black">{diagnosis.seconds}s</div>}
                             </div>
                          </div>
                       </div>
                    </div>

                    {diagnosis.water_now && (
                      <button 
                        onClick={handleWater}
                        disabled={isWatering}
                        className="w-full py-6 bg-primary-gradient text-white rounded-[2rem] font-black uppercase tracking-[0.2em] text-[10px] shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all disabled:opacity-50 disabled:grayscale"
                      >
                        {isWatering ? (
                          <>
                            <Loader2 className="w-5 h-5 animate-spin" /> 
                            Dispensing Hydration ({diagnosis.seconds}s)...
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 fill-current" /> 
                            Execute Watering Sequence
                          </>
                        )}
                      </button>
                    )}
                    
                    {!diagnosis.water_now && (
                      <button 
                        onClick={() => setDiagnosis(null)}
                        className="w-full py-6 bg-white/5 hover:bg-white/10 text-slate-400 rounded-[2rem] font-black uppercase tracking-widest text-[10px] transition-all"
                      >
                        Dismiss Analysis
                      </button>
                    )}
                 </div>
              ) : (
                 <div className="w-full py-12 text-center border-2 border-dashed border-white/5 rounded-[3rem]">
                    <p className="text-slate-500 font-bold text-xs uppercase tracking-widest">Awaiting sensor evaluation request</p>
                 </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <QuotaCard label="Water Satisfaction" value={Math.round(stats?.water.percent || 0)} target={100} unit="%" percent={stats?.water.percent} grad="bg-primary-gradient" />
            <QuotaCard label="Light Satisfaction" value={Math.round(stats?.light.percent || 0)} target={100} unit="%" percent={stats?.light.percent} grad="bg-amber-gradient" />
          </div>

          <div className="bg-white dark:bg-slate-900 p-12 rounded-[4rem] shadow-2xl border border-white dark:border-white/5 relative overflow-hidden">
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/5 blur-[120px] rounded-full"></div>
            
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-16 gap-6 relative z-10">
              <div>
                <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Vital Logs</h2>
                <p className="text-sm font-bold text-slate-400 mt-2 uppercase tracking-widest">Live telemetry feed (5m sync)</p>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/50 px-6 py-3 rounded-2xl flex items-center shadow-inner border border-slate-100 dark:border-white/5">
                <Calendar className="w-4 h-4 text-emerald-500 mr-3" />
                <span className="text-[10px] text-slate-600 dark:text-slate-400 font-black uppercase tracking-widest">{hasEnoughData ? 'Last 12 Samples' : 'Calibrating Baseline'}</span>
              </div>
            </div>

            <div className="h-[400px] relative z-10 flex items-center justify-center">
              {hasEnoughData ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="moistGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10b981" stopOpacity={0.2}/>
                        <stop offset="100%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.15}/>
                        <stop offset="100%" stopColor="#f43f5e" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="10 10" stroke="#f1f5f9" vertical={false} />
                    <XAxis dataKey="interval" hide />
                    <YAxis domain={[0, 100]} hide />
                    <Tooltip content={<CustomChartTooltip />} cursor={{ stroke: '#cbd5e1', strokeWidth: 1 }} />
                    <Area 
                      type="monotone" 
                      name="Moisture" 
                      dataKey="moisture" 
                      stroke="#10b981" 
                      strokeWidth={4} 
                      fill="url(#moistGrad)" 
                      activeDot={{ r: 8, fill: '#10b981', stroke: '#fff', strokeWidth: 4 }}
                    />
                    <Area 
                      type="monotone" 
                      name="Temperature" 
                      dataKey="temperature" 
                      stroke="#f43f5e" 
                      strokeWidth={4} 
                      fill="url(#tempGrad)" 
                      activeDot={{ r: 8, fill: '#f43f5e', stroke: '#fff', strokeWidth: 4 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex flex-col items-center justify-center text-center p-12 bg-slate-50 dark:bg-slate-800/50 rounded-[3rem] border border-dashed border-slate-200 dark:border-slate-700 w-full">
                  <div className="relative mb-6">
                    <div className="absolute inset-0 bg-emerald-500/10 blur-xl animate-pulse"></div>
                    <Activity className="w-12 h-12 text-slate-300 dark:text-slate-600 animate-pulse" />
                  </div>
                  <h4 className="text-lg font-black text-slate-800 dark:text-slate-200 mb-2">Establishing Baseline</h4>
                  <p className="text-sm font-bold text-slate-400 max-w-xs uppercase tracking-widest text-[10px]">Telemetry data requires at least 3 intervals to generate performance trends. Please stand by...</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-6 p-10 bg-emerald-500/5 rounded-[3rem] border border-emerald-500/10">
             <div className="w-16 h-16 bg-primary-gradient rounded-3xl flex items-center justify-center text-white shadow-xl shrink-0">
                <Heart className="w-8 h-8 fill-current" />
             </div>
             <div>
                <h3 className="text-xl font-black text-slate-800 dark:text-white">{label} Ecosystem</h3>
                <p className="text-slate-500 dark:text-slate-400 font-bold text-sm max-w-md leading-relaxed">Your plant is currently categorized as {label.toLowerCase()}. {label === 'Happy' ? 'Maintain current cycles for optimal growth.' : label === 'Neutral' ? 'Minor adjustments to moisture or light may improve performance.' : 'Immediate botanical attention is recommended.'}</p>
             </div>
          </div>
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-2xl animate-in fade-in duration-300">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[4rem] shadow-3xl p-12 text-center border border-white dark:border-white/5">
            <div className="w-24 h-24 bg-rose-500/10 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-8">
              <AlertCircle className="w-12 h-12" />
            </div>
            <h3 className="text-3xl font-black text-slate-900 dark:text-white mb-4">Archive {plant.name}?</h3>
            <p className="text-slate-500 dark:text-slate-400 font-bold leading-relaxed mb-10">
              All botanical telemetry data and care logs will be permanently archived. This action cannot be undone.
            </p>
            <div className="grid grid-cols-1 gap-4">
              <button onClick={onDelete} className="w-full py-6 bg-rose-gradient text-white rounded-[2rem] font-black uppercase tracking-widest text-[10px] shadow-2xl">Confirm Archival</button>
              <button onClick={() => setShowDeleteConfirm(false)} className="w-full py-6 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-[2rem] font-black uppercase tracking-widest text-[10px]">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const StatPlate: React.FC<{ icon: any, label: string, value: string, color: string, bgColor: string }> = ({ icon: Icon, label, value, color, bgColor }) => (
  <div className="flex items-center justify-between p-6 rounded-[2.5rem] bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 transition-all hover:bg-white dark:hover:bg-slate-800">
    <div className="flex items-center gap-6">
        <div className={`w-14 h-14 rounded-2xl ${bgColor} ${color} flex items-center justify-center shadow-sm`}>
            <Icon className="w-6 h-6" />
        </div>
        <div>
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">{label}</p>
            <p className="text-2xl font-black text-slate-800 dark:text-white leading-none">{value}</p>
        </div>
    </div>
  </div>
);

const KnowledgeCard: React.FC<{ icon: any, label: string, content: string, highlight?: boolean }> = ({ icon: Icon, label, content, highlight }) => (
  <div className={`p-8 rounded-[3rem] bg-white dark:bg-slate-900 border ${highlight ? 'border-rose-500/20 bg-rose-500/5' : 'border-slate-100 dark:border-white/5'} shadow-xl flex flex-col items-center text-center h-full min-h-[220px]`}>
    <div className={`w-14 h-14 ${highlight ? 'bg-rose-500/10 text-rose-500' : 'bg-slate-50 dark:bg-slate-800 text-slate-400'} rounded-2xl flex items-center justify-center mb-6 shrink-0`}>
      <Icon className="w-7 h-7" />
    </div>
    <h4 className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-3">{label}</h4>
    <p className="text-sm font-bold text-slate-700 dark:text-slate-200 leading-relaxed line-clamp-6">{content}</p>
  </div>
);

const QuotaCard: React.FC<{ label: string, value: any, target: any, unit: string, percent: any, grad: string }> = ({ label, value, target, unit, percent, grad }) => (
  <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] shadow-xl border border-white dark:border-white/5 relative overflow-hidden group">
    <div className="relative z-10">
       <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-3">{label}</h3>
       <div className="flex items-baseline gap-2 mb-8">
          <span className="text-5xl font-black text-slate-900 dark:text-white">{value}</span>
          <span className="text-sm font-bold text-slate-400">/ {target} {unit}</span>
       </div>
       <div className="w-full bg-slate-50 dark:bg-slate-800 h-3 rounded-full overflow-hidden shadow-inner">
          <div className={`h-full ${grad} rounded-full transition-all duration-1000 shadow-xl group-hover:brightness-110`} style={{ width: `${percent}%` }}></div>
       </div>
    </div>
  </div>
);

export default PlantDetail;
