
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Brain, Search, MapPin, Loader2, Bot, User } from 'lucide-react';
import { Plant, ChatMessage, AIChatType } from '../types';
import { callGeminiAI } from '../services/geminiService';

const AIChat: React.FC<{ plants: Plant[]; initialInput?: string }> = ({ plants, initialInput = '' }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'model', content: "Expert AI Botanist is online. I have analyzed your garden stats. How can I assist?", type: 'FAST' }]);
  const [input, setInput] = useState(initialInput);
  const [selectedType, setSelectedType] = useState<AIChatType>('FAST');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (initialInput) handleSend(initialInput); }, []);
  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages, isLoading]);

  const handleSend = async (overrideInput?: string) => {
    const text = (overrideInput || input).trim();
    if (!text || isLoading) return;
    const isCareRequest = /care guide|how to|needs/i.test(text.toLowerCase());
    const type = isCareRequest ? 'SEARCH' : selectedType;
    setMessages(prev => [...prev, { role: 'user', content: text, type }]);
    setInput('');
    setIsLoading(true);
    try {
      const response = await callGeminiAI(`Context: Garden has ${plants.length} plants. User: ${text}`, type);
      setMessages(prev => [...prev, { 
        role: 'model', 
        content: response.text || 'Error.', 
        type,
        groundingUrls: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((c: any) => ({ title: c.web?.title || 'Resource', uri: c.web?.uri || '#' }))
      }]);
    } catch (err) { setMessages(prev => [...prev, { role: 'system', content: 'Connection failed.' }]); }
    finally { setIsLoading(false); }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-14rem)] max-w-5xl mx-auto bg-white dark:bg-slate-800 rounded-[3.5rem] shadow-2xl border border-slate-100 dark:border-slate-700 overflow-hidden">
      <div className="p-6 bg-slate-50 dark:bg-slate-900 border-b border-slate-100 dark:border-slate-700 flex flex-wrap gap-4">
        <ModeTab active={selectedType === 'FAST'} onClick={() => setSelectedType('FAST')} Icon={Sparkles} label="Fast" grad="bg-primary-gradient" />
        <ModeTab active={selectedType === 'THINKING'} onClick={() => setSelectedType('THINKING')} Icon={Brain} label="Think" grad="bg-rose-gradient" />
        <ModeTab active={selectedType === 'SEARCH'} onClick={() => setSelectedType('SEARCH')} Icon={Search} label="Search" grad="bg-blue-gradient" />
        <ModeTab active={selectedType === 'MAPS'} onClick={() => setSelectedType('MAPS')} Icon={MapPin} label="Nearby" grad="bg-amber-gradient" />
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-10 bg-white dark:bg-slate-800">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
            <div className={`flex max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} gap-6`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${msg.role === 'user' ? 'bg-slate-100 dark:bg-slate-700 text-slate-500' : 'bg-primary-gradient text-white'}`}>
                {msg.role === 'user' ? <User className="w-6 h-6" /> : <Bot className="w-6 h-6" />}
              </div>
              <div className={`p-8 rounded-[2.5rem] shadow-sm border ${msg.role === 'user' ? 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white' : 'bg-white dark:bg-slate-700 border-slate-100 dark:border-slate-600 text-slate-800 dark:text-white shadow-xl'}`}>
                <div className="whitespace-pre-wrap leading-relaxed text-sm font-bold">{msg.content}</div>
                {msg.groundingUrls?.length ? (
                  <div className="mt-6 flex flex-wrap gap-2 pt-6 border-t border-slate-100 dark:border-slate-600">
                    {msg.groundingUrls.map((l, j) => <a key={j} href={l.uri} target="_blank" className="px-4 py-2 bg-slate-50 dark:bg-slate-900 rounded-xl text-[10px] font-black uppercase text-emerald-600 dark:text-emerald-400 shadow-sm border border-slate-100 dark:border-slate-800 hover:scale-105 transition-transform">{l.title}</a>)}
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="p-10 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-700">
        <div className="relative flex items-center max-w-2xl mx-auto">
          <input type="text" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="Consult with AI Botanist..." className="w-full pl-10 pr-24 py-6 bg-white dark:bg-slate-800 rounded-full text-sm font-bold shadow-xl outline-none focus:ring-4 focus:ring-emerald-500/10 dark:text-white" />
          <button onClick={() => handleSend()} disabled={!input.trim() || isLoading} className="absolute right-3 p-5 gradient-btn rounded-full">{isLoading ? <Loader2 className="animate-spin" /> : <Send />}</button>
        </div>
      </div>
    </div>
  );
};

const ModeTab: React.FC<{ active: boolean; onClick: () => void; Icon: any; label: string, grad: string }> = ({ active, onClick, Icon, label, grad }) => (
  <button onClick={onClick} className={`flex items-center px-6 py-3 rounded-2xl transition-all ${active ? 'bg-white dark:bg-slate-800 shadow-xl border border-slate-100 dark:border-slate-700 -translate-y-1' : 'opacity-40 hover:opacity-100'}`}>
    <div className={`p-2.5 rounded-xl mr-4 ${active ? grad : 'bg-slate-200 dark:bg-slate-800'} text-white shadow-lg`}>
      <Icon className="w-5 h-5" />
    </div>
    <span className={`text-[11px] font-black uppercase tracking-widest ${active ? 'text-slate-800 dark:text-white' : 'text-slate-400'}`}>{label}</span>
  </button>
);

export default AIChat;
