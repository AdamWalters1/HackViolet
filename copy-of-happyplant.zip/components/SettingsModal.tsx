
import React, { useState } from 'react';
import { X, Settings, Bell, Thermometer, Database, User, ShieldAlert, RefreshCcw, Moon, Sun } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  settings: AppSettings;
  onClose: () => void;
  onSave: (settings: AppSettings) => void;
  onReset: () => void;
}

type SettingsCategory = 'PROFILE' | 'ALERTS' | 'DISPLAY' | 'SYNC';

const SettingsModal: React.FC<SettingsModalProps> = ({ settings, onClose, onSave, onReset }) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>({ ...settings });
  const [activeCategory, setActiveCategory] = useState<SettingsCategory>('PROFILE');

  const handleToggle = (key: keyof AppSettings['notifications']) => {
    setLocalSettings(prev => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [key]: !prev.notifications[key]
      }
    }));
  };

  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white dark:bg-slate-800 w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/50 dark:border-slate-700 animate-in zoom-in-95 duration-300 flex flex-col max-h-[85vh]">
        
        {/* Header - Fixed */}
        <div className="bg-slate-800 dark:bg-slate-900 p-6 md:p-8 text-white relative shrink-0">
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 p-2 hover:bg-white/20 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center mb-1">
             <div className="p-2 bg-white/10 rounded-xl mr-3">
                <Settings className="w-5 h-5" />
             </div>
             <h2 className="text-xl font-black tracking-tight">App Configuration</h2>
          </div>
          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Customize your greenhouse experience</p>
        </div>

        <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
          {/* Navigation/Categories - Scrollable on mobile if many items */}
          <div className="w-full md:w-52 bg-slate-50 dark:bg-slate-900/40 border-r border-slate-100 dark:border-slate-700 p-4 space-y-1 overflow-x-auto md:overflow-y-auto flex flex-row md:flex-col shrink-0">
             <SidebarItem 
               active={activeCategory === 'PROFILE'} 
               onClick={() => setActiveCategory('PROFILE')}
               icon={<User className="w-3.5 h-3.5" />} 
               label="Profile" 
             />
             <SidebarItem 
               active={activeCategory === 'ALERTS'} 
               onClick={() => setActiveCategory('ALERTS')}
               icon={<Bell className="w-3.5 h-3.5" />} 
               label="Alerts" 
             />
             <SidebarItem 
               active={activeCategory === 'DISPLAY'} 
               onClick={() => setActiveCategory('DISPLAY')}
               icon={<Thermometer className="w-3.5 h-3.5" />} 
               label="Display" 
             />
             <SidebarItem 
               active={activeCategory === 'SYNC'} 
               onClick={() => setActiveCategory('SYNC')}
               icon={<RefreshCcw className="w-3.5 h-3.5" />} 
               label="Sync" 
             />
          </div>

          {/* Content Area - Scrollable */}
          <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 animate-in fade-in slide-in-from-right-4 duration-300" key={activeCategory}>
            
            {activeCategory === 'PROFILE' && (
              <section className="space-y-6">
                <div>
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Keeper Identity</h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-600 dark:text-slate-400 ml-1">Greenhouse Name</label>
                      <input 
                        type="text"
                        className="w-full px-5 py-4 bg-slate-100 dark:bg-slate-900/60 border-none rounded-2xl font-bold text-slate-800 dark:text-slate-100 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all"
                        value={localSettings.keeperName}
                        onChange={e => setLocalSettings(prev => ({ ...prev, keeperName: e.target.value }))}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 dark:border-slate-700">
                  <h3 className="text-[10px] font-bold text-slate-800 dark:text-slate-200 mb-2">About Your Account</h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                    Your profile information is used to personalize the AI Assistant and your garden reports. 
                    All data is stored locally in your browser.
                  </p>
                </div>
              </section>
            )}

            {activeCategory === 'ALERTS' && (
              <section className="space-y-6">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Smart Notifications</h3>
                <div className="space-y-3">
                  <ToggleItem 
                    label="Thirsty Alerts" 
                    desc="Notifications for low moisture"
                    active={localSettings.notifications.moistureAlerts}
                    onToggle={() => handleToggle('moistureAlerts')}
                  />
                  <ToggleItem 
                    label="Temp Warnings" 
                    desc="Frost or heat spike alerts"
                    active={localSettings.notifications.tempAlerts}
                    onToggle={() => handleToggle('tempAlerts')}
                  />
                  <ToggleItem 
                    label="Light Exposure" 
                    desc="Daily sun absorption summaries"
                    active={localSettings.notifications.lightAlerts}
                    onToggle={() => handleToggle('lightAlerts')}
                  />
                </div>
              </section>
            )}

            {activeCategory === 'DISPLAY' && (
              <section className="space-y-8">
                <div>
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Theme & Units</h3>
                  <div className="space-y-6">
                    <div className="p-5 bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-slate-100 dark:border-slate-700">
                      <p className="text-[10px] font-bold text-slate-600 dark:text-slate-400 mb-4 uppercase tracking-widest">Appearance</p>
                      <div className="flex bg-slate-200 dark:bg-slate-900 p-1 rounded-xl w-max">
                        <button 
                          onClick={() => setLocalSettings(prev => ({ ...prev, darkMode: false }))}
                          className={`flex items-center px-4 py-2 rounded-lg text-[9px] font-black transition-all ${!localSettings.darkMode ? 'bg-white shadow-md text-emerald-600' : 'text-slate-500'}`}
                        >
                          <Sun className="w-3 h-3 mr-2" /> LIGHT
                        </button>
                        <button 
                          onClick={() => setLocalSettings(prev => ({ ...prev, darkMode: true }))}
                          className={`flex items-center px-4 py-2 rounded-lg text-[9px] font-black transition-all ${localSettings.darkMode ? 'bg-white dark:bg-slate-800 shadow-md text-emerald-600 dark:text-emerald-400' : 'text-slate-500'}`}
                        >
                          <Moon className="w-3 h-3 mr-2" /> DARK
                        </button>
                      </div>
                    </div>

                    <div className="p-5 bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-slate-100 dark:border-slate-700">
                      <p className="text-[10px] font-bold text-slate-600 dark:text-slate-400 mb-4 uppercase tracking-widest">Temperature Scale</p>
                      <div className="flex bg-slate-200 dark:bg-slate-900 p-1 rounded-xl w-max">
                        <button 
                          onClick={() => setLocalSettings(prev => ({ ...prev, tempUnit: 'C' }))}
                          className={`px-6 py-2 rounded-lg text-[9px] font-black transition-all ${localSettings.tempUnit === 'C' ? 'bg-white dark:bg-slate-800 shadow-md text-emerald-600 dark:text-emerald-400' : 'text-slate-500'}`}
                        >
                          CELSIUS (°C)
                        </button>
                        <button 
                          onClick={() => setLocalSettings(prev => ({ ...prev, tempUnit: 'F' }))}
                          className={`px-6 py-2 rounded-lg text-[9px] font-black transition-all ${localSettings.tempUnit === 'F' ? 'bg-white dark:bg-slate-800 shadow-md text-emerald-600 dark:text-emerald-400' : 'text-slate-500'}`}
                        >
                          FAHRENHEIT (°F)
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {activeCategory === 'SYNC' && (
              <section className="space-y-6">
                <div>
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Sync Frequency</h3>
                  <div className="p-5 bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-slate-100 dark:border-slate-700">
                    <p className="text-[10px] font-bold text-slate-600 dark:text-slate-400 mb-4 uppercase tracking-widest">Live Telemetry Refresh Rate</p>
                    <select 
                      value={localSettings.syncInterval}
                      onChange={e => setLocalSettings(prev => ({ ...prev, syncInterval: parseInt(e.target.value) }))}
                      className="w-full px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-800 dark:text-slate-100 outline-none text-xs"
                    >
                      <option value={1}>Every Minute</option>
                      <option value={5}>Every 5 Minutes</option>
                      <option value={15}>Every 15 Minutes</option>
                      <option value={60}>Every Hour</option>
                    </select>
                    <p className="mt-4 text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                      Lower intervals provide more precise historical charts.
                    </p>
                  </div>
                </div>

                <div className="pt-6 border-t border-red-50 dark:border-red-900/20">
                   <button 
                     onClick={onReset}
                     className="flex items-center px-6 py-4 bg-red-50 dark:bg-red-900/10 text-red-600 dark:text-red-400 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-100 dark:hover:bg-red-900/20 transition-all border border-red-100/50 dark:border-red-900/20 w-full"
                   >
                     <Database className="w-3.5 h-3.5 mr-2" /> Factory Reset Garden
                   </button>
                </div>
              </section>
            )}

          </div>
        </div>

        {/* Footer - Fixed */}
        <div className="p-6 md:p-8 bg-slate-50 dark:bg-slate-900/60 border-t border-slate-100 dark:border-slate-700 flex justify-end gap-3 shrink-0">
          <button 
            onClick={onClose}
            className="px-6 py-3 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            className="px-8 py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-200 dark:shadow-none hover:bg-emerald-700 transition-all"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

const SidebarItem: React.FC<{ active?: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex-1 md:w-full flex items-center justify-center md:justify-start px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${active ? 'bg-white dark:bg-slate-800 shadow-sm text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400 hover:bg-white/50 dark:hover:bg-slate-800/50'}`}
  >
    <span className="md:mr-3">{icon}</span>
    <span className="hidden md:inline text-[11px] font-black uppercase tracking-widest">{label}</span>
  </button>
);

const ToggleItem: React.FC<{ label: string; desc: string; active: boolean; onToggle: () => void }> = ({ label, desc, active, onToggle }) => (
  <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
    <div className="pr-4">
      <p className="text-xs font-black text-slate-800 dark:text-slate-100 leading-none">{label}</p>
      <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 mt-1.5 uppercase tracking-widest">{desc}</p>
    </div>
    <button 
      onClick={onToggle}
      className={`w-10 h-5 rounded-full p-0.5 transition-all duration-300 shrink-0 ${active ? 'bg-emerald-500' : 'bg-slate-200 dark:bg-slate-700'}`}
    >
      <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-300 ${active ? 'translate-x-5' : 'translate-x-0'}`} />
    </button>
  </div>
);

export default SettingsModal;
