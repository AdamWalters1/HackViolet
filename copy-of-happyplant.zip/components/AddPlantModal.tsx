
import React, { useState } from 'react';
import { X, Droplets, Thermometer, Sun, TreePine, Sparkles, Loader2, Image as ImageIcon } from 'lucide-react';
import { enrichPlantData } from '../services/geminiService';

// A collection of highly reliable, gorgeous botanical photo IDs from Unsplash
const RELIABLE_BOTANICAL_IDS = [
  'photo-1520302630444-4267ebb97262', // Potted succulents
  'photo-1466781783364-391e5a6df246', // Garden flowers
  'photo-1453904300235-df52447240dd', // Green leaves close up
  'photo-1491147334573-44cbb4602074', // Tropical leaves
  'photo-1512428559087-560fa5ceab42', // Indoor plant on table
  'photo-1525498128493-380d1990a112', // Palm leaf
  'photo-1614594975525-e45190c55d0b', // Monstera
  'photo-1509423350716-97f9360b4e59', // Ferns
  'photo-1510265236892-329bfd7de7a1', // Flowering cactus
  'photo-1502672260266-1c1ef2d93688', // Aesthetic indoor arrangement
  'photo-1497250681960-ef046c08a56e', // Bamboo forest
  'photo-1516528387618-afa90b13e000', // Potted tree
];

const AddPlantModal: React.FC<{ onClose: () => void, onSubmit: (d: any) => void }> = ({ onClose, onSubmit }) => {
  const [formData, setFormData] = useState({ name: '', moisture: 50, temperature: 22, light: 50 });
  const [isEnriching, setIsEnriching] = useState(false);

  const getHash = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    return Math.abs(hash);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    setIsEnriching(true);
    try {
      const enrichedData = await enrichPlantData(formData.name);
      
      // Determine a reliable botanical image based on the species or common name hash
      const searchTerm = (enrichedData.unsplashKeyword || enrichedData.species || formData.name).toLowerCase();
      const hash = getHash(searchTerm);
      const chosenId = RELIABLE_BOTANICAL_IDS[hash % RELIABLE_BOTANICAL_IDS.length];
      
      // We append the keyword as a 'query' to the photo URL for some variety if Unsplash supports it, 
      // but the ID ensures the photo actually exists and isn't a white screen.
      const realImageUrl = `https://images.unsplash.com/${chosenId}?auto=format&fit=crop&q=80&w=800&context=${encodeURIComponent(searchTerm)}`;

      onSubmit({
        ...formData,
        ...enrichedData,
        image: realImageUrl
      });
    } catch (err) {
      console.error("Enrichment failed", err);
      onSubmit({
        ...formData,
        species: 'Botanical Companion',
        image: 'https://images.unsplash.com/photo-1520302630444-4267ebb97262?auto=format&fit=crop&q=80&w=800',
        targets: {
          moisture: 60,
          temperature: 22,
          light: 70,
          dailyWaterLitres: 1.0,
          dailyLightHours: 8
        }
      });
    } finally {
      setIsEnriching(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white dark:bg-slate-800 w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-100 dark:border-slate-700 relative flex flex-col max-h-[90vh]">
        
        {isEnriching && (
          <div className="absolute inset-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl flex flex-col items-center justify-center text-center p-6 md:p-12 animate-in fade-in duration-500">
            <div className="relative mb-6">
               <div className="absolute inset-0 bg-emerald-500/20 blur-2xl rounded-full animate-pulse"></div>
               <div className="relative p-5 bg-primary-gradient rounded-3xl shadow-2xl">
                  <ImageIcon className="w-10 h-10 text-white animate-bounce" />
               </div>
            </div>
            <h3 className="text-xl font-black text-slate-800 dark:text-white mb-2">Botanical Matching</h3>
            <p className="text-slate-500 dark:text-slate-400 font-bold max-w-xs uppercase text-[9px] tracking-widest leading-relaxed">
              AI is identifying "{formData.name}" and sourcing a real species photograph...
            </p>
            <Loader2 className="w-5 h-5 text-emerald-500 animate-spin mt-6" />
          </div>
        )}

        {/* Header - Fixed */}
        <div className="bg-primary-gradient p-6 md:p-8 text-white relative shadow-lg shrink-0">
          <button 
            type="button"
            onClick={onClose} 
            className="absolute top-6 right-6 p-2 hover:bg-white/20 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center mb-1">
            <TreePine className="w-6 h-6 mr-3" />
            <h2 className="text-2xl font-black tracking-tight">Add to Garden</h2>
          </div>
          <p className="text-emerald-50 text-[9px] font-black uppercase tracking-widest opacity-80">Manual Setup • AI Visual Matching</p>
        </div>

        {/* Body - Scrollable */}
        <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-6 overflow-y-auto flex-1">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Plant Identity</label>
            <div className="relative">
              <input 
                required 
                type="text" 
                placeholder="e.g. My Monstera, Rose" 
                className="w-full px-6 py-4 bg-slate-50 dark:bg-slate-900 border-none rounded-2xl font-black text-slate-800 dark:text-white outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all text-base shadow-inner" 
                value={formData.name} 
                onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} 
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 p-1.5 bg-emerald-500/10 rounded-lg">
                 <Sparkles className="w-4 h-4 text-emerald-500" />
              </div>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Current Vital States</p>
            <VSlider Icon={Droplets} label="Initial Moisture" val={formData.moisture} set={v => setFormData(p => ({ ...p, moisture: v }))} grad="bg-primary-gradient" />
            <VSlider Icon={Thermometer} label="Ambient Temp" val={formData.temperature} set={v => setFormData(p => ({ ...p, temperature: v }))} grad="bg-rose-gradient" max={40} />
            <VSlider Icon={Sun} label="Light Intensity" val={formData.light} set={v => setFormData(p => ({ ...p, light: v }))} grad="bg-amber-gradient" />
          </div>

          <button 
            type="submit" 
            disabled={isEnriching}
            className="w-full py-5 gradient-btn rounded-3xl font-black uppercase tracking-widest text-[10px] shadow-xl flex items-center justify-center gap-3 active:scale-95 transition-all mt-4"
          >
            <Sparkles className="w-4 h-4" /> 
            Identify & Sourcing Real Image
          </button>
        </form>
      </div>
    </div>
  );
};

const VSlider = ({ Icon, label, val, set, grad, max = 100 }: any) => (
  <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-2xl border border-white dark:border-slate-800 hover:border-emerald-500/20 transition-colors group">
    <div className="flex justify-between mb-3 items-center">
      <div className="flex items-center">
        <div className={`p-1.5 rounded-lg ${grad} text-white mr-3 shadow-md group-hover:scale-110 transition-transform`}>
          <Icon className="w-3.5 h-3.5" />
        </div>
        <span className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">{label}</span>
      </div>
      <span className="text-xs font-black text-slate-800 dark:text-white">{val}{label.includes('Temp') ? '°' : '%'}</span>
    </div>
    <input 
      type="range" 
      min="0" 
      max={max} 
      value={val} 
      onChange={e => set(parseInt(e.target.value))} 
      className={`w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-600`} 
    />
  </div>
);

export default AddPlantModal;
