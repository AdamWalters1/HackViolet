
import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, RefreshCw, Check, Sparkles, Loader2, ScanLine, ArrowRight, TreePine, AlertCircle } from 'lucide-react';
import { identifyPlantFromImage } from '../services/geminiService';

interface IdentifyPlantModalProps {
  onClose: () => void;
  onAddPlant: (data: any) => void;
}

const IdentifyPlantModal: React.FC<IdentifyPlantModalProps> = ({ onClose, onAddPlant }) => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isIdentifying, setIsIdentifying] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: { ideal: 1080 }, height: { ideal: 1920 } }, 
        audio: false 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      setError('Camera access denied. Please check permissions.');
    }
  };

  useEffect(() => {
    startCamera();
    return () => {
      stream?.getTracks().forEach(track => track.stop());
    };
  }, []);

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      setCapturedImage(dataUrl);
      
      stream?.getTracks().forEach(track => track.stop());
      setStream(null);
      
      handleIdentify(dataUrl);
    }
  };

  const handleIdentify = async (img: string) => {
    setIsIdentifying(true);
    setError(null);
    try {
      const data = await identifyPlantFromImage(img);
      setResult(data);
    } catch (err) {
      setError('Identification failed. Try a clearer photo.');
    } finally {
      setIsIdentifying(false);
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
    setResult(null);
    setError(null);
    startCamera();
  };

  const handleConfirm = () => {
    if (result) {
      onAddPlant({
        commonName: result.commonName,
        species: result.species,
        image: capturedImage,
        ...result.targets,
        targets: result.targets
      });
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-xl flex flex-col animate-in fade-in duration-300 overflow-y-auto">
      <div className="p-4 md:p-6 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-3">
            <div className="p-2 bg-primary-gradient rounded-xl shadow-lg">
                <Sparkles className="w-4 h-4 text-white" />
            </div>
            <h2 className="text-sm font-black text-white uppercase tracking-widest">Vision Lab</h2>
        </div>
        <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center p-4">
        {!capturedImage ? (
          <div className="w-full max-w-sm aspect-[3/4] rounded-[2.5rem] overflow-hidden bg-black relative border-4 border-white/20 shadow-2xl">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-48 h-48 border-2 border-white/20 border-dashed rounded-3xl"></div>
            </div>
            <div className="absolute bottom-6 left-0 right-0 flex justify-center">
              <button 
                onClick={capturePhoto}
                className="w-16 h-16 rounded-full bg-white p-1 border-4 border-slate-900 shadow-2xl active:scale-90 transition-transform flex items-center justify-center"
              >
                <div className="w-full h-full rounded-full bg-primary-gradient shadow-inner"></div>
              </button>
            </div>
          </div>
        ) : (
          <div className="w-full max-w-sm aspect-[3/4] rounded-[2.5rem] overflow-hidden bg-slate-800 relative border-4 border-white/20 shadow-2xl">
            <img src={capturedImage} className="w-full h-full object-cover" />
            {isIdentifying && (
              <div className="absolute inset-0 bg-black/20 overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-primary-gradient animate-[scan_2s_infinite] shadow-[0_0_20px_#10b981]"></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-black/40 backdrop-blur-sm">
                   <Loader2 className="w-10 h-10 animate-spin mb-3" />
                   <p className="font-black uppercase tracking-widest text-[9px]">AI is Analyzing...</p>
                </div>
              </div>
            )}
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />
      </div>

      {result && (
        <div className="p-4 md:p-6 pb-8 animate-in slide-in-from-bottom-8 duration-500">
          <div className="bg-white dark:bg-slate-800 rounded-[2.5rem] p-6 md:p-8 max-w-lg mx-auto shadow-2xl border border-white/50 relative overflow-hidden">
             <div className="absolute -top-4 -right-4 p-4 text-emerald-500/5 hidden md:block">
                <TreePine className="w-32 h-32" />
             </div>
             
             <div className="relative z-10">
               <div className="flex items-center gap-2 mb-2">
                 <span className="px-2 py-0.5 bg-primary-gradient text-white text-[8px] font-black uppercase tracking-widest rounded shadow-md">Match Found</span>
                 <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest truncate">{result.species}</span>
               </div>
               <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">{result.commonName}</h3>
               <p className="text-xs font-medium text-slate-500 dark:text-slate-400 leading-relaxed mb-6 line-clamp-2 md:line-clamp-none">
                 {result.description}
               </p>
               
               <div className="grid grid-cols-2 gap-3 mb-6">
                  <ResultStat label="Watering" value={`${result.targets?.moisture || 50}%`} grad="bg-primary-gradient" />
                  <ResultStat label="Sunlight" value={`${result.targets?.dailyLightHours || 8}h`} grad="bg-amber-gradient" />
               </div>

               <div className="flex gap-3">
                 <button 
                   onClick={handleRetake}
                   className="flex-1 py-4 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-2xl font-black uppercase tracking-widest text-[9px] flex items-center justify-center"
                 >
                   <RefreshCw className="w-3.5 h-3.5 mr-2" /> Retake
                 </button>
                 <button 
                   onClick={handleConfirm}
                   className="flex-[2] py-4 bg-primary-gradient text-white rounded-2xl font-black uppercase tracking-widest text-[9px] flex items-center justify-center shadow-lg shadow-emerald-200/50"
                 >
                   Confirm & Add <ArrowRight className="w-3.5 h-3.5 ml-2" />
                 </button>
               </div>
             </div>
          </div>
        </div>
      )}

      {error && !isIdentifying && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 bg-rose-500 text-white px-6 py-3 rounded-xl shadow-2xl font-black uppercase tracking-widest text-[9px] flex items-center whitespace-nowrap">
           <AlertCircle className="w-3.5 h-3.5 mr-2" /> {error}
           <button onClick={handleRetake} className="ml-4 underline">Retry</button>
        </div>
      )}

      <style>{`
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </div>
  );
};

const ResultStat = ({ label, value, grad }: any) => (
  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-700 flex flex-col items-center text-center">
    <div className={`w-6 h-0.5 ${grad} rounded-full mb-1.5`}></div>
    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{label}</p>
    <p className="text-xs font-black text-slate-800 dark:text-white">{value}</p>
  </div>
);

export default IdentifyPlantModal;
