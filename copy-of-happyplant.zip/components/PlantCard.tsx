
import React, { useMemo, useRef, useState } from 'react';
import { Droplets, Thermometer, Sun, Camera, ChevronRight } from 'lucide-react';
import { Plant } from '../types';

interface PlantCardProps {
  plant: Plant;
  onClick: () => void;
  onUpdateImage?: (newImage: string) => void;
}

/**
 * Health Logic Implementation:
 * Below 33% fulfillment: Unhappy
 * 34-67% fulfillment: Neutral
 * 67% and above: Happy
 */
export const getHealthData = (plant: Plant) => {
  const last = plant.conditions[plant.conditions.length - 1];
  if (!last) return { score: 50, mood: '😐', label: 'Waiting', color: 'text-white', gradient: 'bg-slate-400' };

  const targets = plant.targets || { moisture: 55, temperature: 22, light: 50 };
  
  // Calculate how close we are to targets (0-100 satisfaction)
  const moistureSatisfaction = Math.max(0, 100 - Math.abs(last.moisture - targets.moisture) * 1.5);
  const lightSatisfaction = Math.max(0, 100 - Math.abs(last.light - targets.light) * 1.5);
  
  // Overall score is the average satisfaction
  const score = Math.round((moistureSatisfaction + lightSatisfaction) / 2);

  if (score < 33) {
    return { 
      score, 
      mood: '🥀', 
      label: 'Unhappy', 
      color: 'text-white', 
      gradient: 'bg-rose-gradient' 
    };
  }
  
  if (score <= 67) {
    return { 
      score, 
      mood: '😐', 
      label: 'Neutral', 
      color: 'text-white', 
      gradient: 'bg-amber-gradient' 
    };
  }
  
  return { 
    score, 
    mood: '🌿', 
    label: 'Happy', 
    color: 'text-white', 
    gradient: 'bg-primary-gradient' 
  };
};

const PlantCard: React.FC<PlantCardProps> = ({ plant, onClick, onUpdateImage }) => {
  const lastUpdate = plant.conditions[plant.conditions.length - 1];
  const { mood, label, color, gradient, score } = getHealthData(plant);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imgError, setImgError] = useState(false);

  const absoluteStats = useMemo(() => {
    if (!plant.targets) return null;
    const moistureValue = lastUpdate?.moisture || 0;
    // We calculate fulfillment relative to targets
    const waterPercent = Math.min(100, Math.max(0, 100 - Math.abs(moistureValue - plant.targets.moisture) * 2));
    
    const avgLight = plant.conditions.reduce((acc, c) => acc + c.light, 0) / (plant.conditions.length || 1);
    const lightPercent = Math.min(100, Math.max(0, 100 - Math.abs(avgLight - plant.targets.light) * 2));

    return {
      water: { percent: waterPercent },
      light: { percent: lightPercent }
    };
  }, [plant, lastUpdate]);

  const handleCameraClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onUpdateImage) {
      const reader = new FileReader();
      reader.onloadend = () => onUpdateImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const displayImage = imgError 
    ? "https://images.unsplash.com/photo-1520302630444-4267ebb97262?auto=format&fit=crop&q=80&w=800" 
    : plant.image;

  return (
    <div 
      onClick={onClick}
      className="minimal-3d-card group rounded-[2.5rem] overflow-hidden cursor-pointer bg-white dark:bg-slate-900 flex flex-col"
    >
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" capture="environment" onChange={handleFileChange} />
      
      <div className="relative aspect-[4/3] overflow-hidden rounded-t-[2.5rem] bg-slate-100 dark:bg-slate-800">
        <img 
          src={displayImage} 
          alt={plant.name} 
          onError={() => setImgError(true)}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000 ease-out" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
        
        <div className="absolute top-4 left-4">
            <div className={`px-4 py-2 ${gradient} rounded-2xl flex items-center shadow-2xl backdrop-blur-sm bg-opacity-90`}>
                <span className="text-xl mr-2">{mood}</span>
                <span className={`text-[10px] font-black uppercase tracking-widest ${color}`}>{label}</span>
            </div>
        </div>

        <button 
          onClick={handleCameraClick}
          className="absolute top-4 right-4 p-3 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-2xl border border-white/20 text-white opacity-0 group-hover:opacity-100 transition-all shadow-xl"
        >
          <Camera className="w-5 h-5" />
        </button>
      </div>
      
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-1">
          <h3 className="text-2xl font-black text-slate-800 dark:text-slate-100 truncate">{plant.name}</h3>
          <div className="p-1.5 bg-slate-100 dark:bg-slate-800 rounded-full text-slate-400 group-hover:text-emerald-500 transition-colors">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
        <p className="text-xs font-bold text-slate-400 dark:text-slate-500 mb-6 uppercase tracking-widest">{plant.species}</p>
        
        <div className="grid grid-cols-1 gap-4 mb-6">
           {absoluteStats && (
             <>
               <div className="space-y-1.5">
                  <div className="flex justify-between items-end">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Hydration Balance</span>
                    <span className="text-[10px] font-black text-slate-800 dark:text-slate-200">
                      {Math.round(absoluteStats.water.percent)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary-gradient rounded-full transition-all duration-1000" 
                      style={{ width: `${absoluteStats.water.percent}%` }}
                    ></div>
                  </div>
               </div>
               <div className="space-y-1.5">
                  <div className="flex justify-between items-end">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Solar Balance</span>
                    <span className="text-[10px] font-black text-slate-800 dark:text-slate-200">
                      {Math.round(absoluteStats.light.percent)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-amber-gradient rounded-full transition-all duration-1000" 
                      style={{ width: `${absoluteStats.light.percent}%` }}
                    ></div>
                  </div>
               </div>
             </>
           )}
        </div>

        <div className="mt-auto flex items-center justify-between gap-3 pt-4 border-t border-slate-50 dark:border-slate-800/50">
          <MetricBadge Icon={Droplets} value={`${Math.round(lastUpdate?.moisture || 0)}%`} activeColor="text-emerald-500" bgColor="bg-emerald-500/10" />
          <MetricBadge Icon={Thermometer} value={`${Math.round(lastUpdate?.temperature || 0)}°`} activeColor="text-rose-500" bgColor="bg-rose-500/10" />
          <MetricBadge Icon={Sun} value={`${Math.round(lastUpdate?.light || 0)}%`} activeColor="text-amber-500" bgColor="bg-amber-500/10" />
        </div>
      </div>
    </div>
  );
};

const MetricBadge: React.FC<{ Icon: any, value: string, activeColor: string, bgColor: string }> = ({ Icon, value, activeColor, bgColor }) => (
  <div className="flex flex-col items-center gap-1 flex-1">
    <div className={`p-2 rounded-xl ${bgColor} ${activeColor} mb-1`}>
        <Icon className="w-4 h-4" />
    </div>
    <span className="text-xs font-black text-slate-700 dark:text-slate-200">{value}</span>
  </div>
);

export default PlantCard;
