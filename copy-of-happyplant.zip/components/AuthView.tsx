
import React, { useState } from 'react';
import { TreePine, Mail, Lock, User as UserIcon, ArrowRight, Sparkles, Check, ChevronLeft } from 'lucide-react';
import { User } from '../types';

interface AuthViewProps {
  onLogin: (user: User) => void;
}

const AVATARS = [
  "🌿", "🌵", "🌸", "🍄", "🌳", "🌻"
];

const AuthView: React.FC<AuthViewProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<'LOGIN' | 'SIGNUP'>('LOGIN');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0]);
  const [error, setError] = useState('');

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const accountsStr = localStorage.getItem('happy_plant_accounts');
    const accounts: User[] = accountsStr ? JSON.parse(accountsStr) : [];

    if (mode === 'LOGIN') {
      const user = accounts.find(a => a.email === email && a.password === password);
      if (user) {
        onLogin(user);
      } else {
        setError('Invalid credentials. Try again or join the garden.');
      }
    } else {
      if (accounts.some(a => a.email === email)) {
        setError('Email already registered.');
        return;
      }
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name,
        email,
        password,
        avatar: selectedAvatar
      };
      accounts.push(newUser);
      localStorage.setItem('happy_plant_accounts', JSON.stringify(accounts));
      onLogin(newUser);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-start py-12 px-4 md:px-8 overflow-x-hidden relative">
      {/* Background Pulse Decorations */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-emerald-500/10 blur-[120px] rounded-full animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-amber-500/10 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="w-full max-w-2xl my-auto relative z-10 animate-in fade-in zoom-in-95 duration-700">
        <div className="bg-white/5 backdrop-blur-3xl border border-white/10 p-8 md:p-14 rounded-[3rem] md:rounded-[4.5rem] shadow-3xl text-center">
          
          <div className="mb-10 inline-flex flex-col items-center">
            <div className="p-4 md:p-5 bg-primary-gradient rounded-[1.5rem] md:rounded-[2rem] shadow-2xl shadow-emerald-500/30 mb-6 rotate-3 transform hover:rotate-0 transition-transform duration-500">
              <TreePine className="w-8 h-8 md:w-12 md:h-12 text-white" />
            </div>
            <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight mb-2">HappyPlant</h1>
            <p className="text-emerald-400 font-black uppercase tracking-[0.3em] text-[9px] md:text-[11px]">Your Botanical Ecosystem</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-6 md:space-y-8 text-left max-w-lg mx-auto">
            {mode === 'SIGNUP' && (
              <div className="space-y-6 md:space-y-8 animate-in slide-in-from-top-4 duration-500">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Your Name</label>
                  <div className="relative group">
                    <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-emerald-500 transition-colors" />
                    <input 
                      required 
                      type="text" 
                      placeholder="Botanist Name" 
                      className="w-full pl-14 pr-6 py-4 md:py-5 bg-white/5 border border-white/10 rounded-[1.5rem] md:rounded-3xl text-white font-bold outline-none focus:ring-4 focus:ring-emerald-500/20 focus:border-emerald-500/30 transition-all placeholder:text-slate-600"
                      value={name}
                      onChange={e => setName(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 text-center block">Choose Your Guardian</label>
                  <div className="flex justify-center gap-3 md:gap-5">
                    {AVATARS.map(ava => (
                      <button
                        key={ava}
                        type="button"
                        onClick={() => setSelectedAvatar(ava)}
                        className={`w-12 h-12 md:w-16 md:h-16 rounded-2xl md:rounded-[1.5rem] flex items-center justify-center text-xl md:text-3xl transition-all ${
                          selectedAvatar === ava ? 'bg-primary-gradient scale-110 shadow-2xl ring-2 ring-emerald-500/50' : 'bg-white/5 hover:bg-white/10 opacity-50 grayscale hover:grayscale-0 hover:opacity-100'
                        }`}
                      >
                        {ava}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-emerald-500 transition-colors" />
                <input 
                  required 
                  type="email" 
                  placeholder="name@example.com" 
                  className="w-full pl-14 pr-6 py-4 md:py-5 bg-white/5 border border-white/10 rounded-[1.5rem] md:rounded-3xl text-white font-bold outline-none focus:ring-4 focus:ring-emerald-500/20 focus:border-emerald-500/30 transition-all placeholder:text-slate-600"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Password</label>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-emerald-500 transition-colors" />
                <input 
                  required 
                  type="password" 
                  placeholder="••••••••" 
                  className="w-full pl-14 pr-6 py-4 md:py-5 bg-white/5 border border-white/10 rounded-[1.5rem] md:rounded-3xl text-white font-bold outline-none focus:ring-4 focus:ring-emerald-500/20 focus:border-emerald-500/30 transition-all placeholder:text-slate-600"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                />
              </div>
            </div>

            {error && (
              <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-400 text-[10px] font-black uppercase tracking-widest text-center animate-in shake duration-300">
                {error}
              </div>
            )}

            <button 
              type="submit" 
              className="w-full py-5 md:py-6 bg-primary-gradient text-white rounded-[2rem] md:rounded-[2.5rem] font-black uppercase tracking-widest text-[10px] shadow-2xl shadow-emerald-500/20 flex items-center justify-center group hover:scale-[1.02] active:scale-95 transition-all mt-4"
            >
              {mode === 'LOGIN' ? 'Enter Greenhouse' : 'Begin My Garden'}
              <ArrowRight className="w-4 h-4 ml-3 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="mt-8 md:mt-12 pt-8 md:pt-12 border-t border-white/5 flex flex-col items-center">
            <p className="text-slate-500 font-bold text-xs mb-4">
              {mode === 'LOGIN' ? "New to botanical tracking?" : "Already a member?"}
            </p>
            <button 
              onClick={() => { setMode(mode === 'LOGIN' ? 'SIGNUP' : 'LOGIN'); setError(''); }}
              className="px-10 py-4 bg-white/5 hover:bg-white/10 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest border border-white/10 transition-all active:scale-95 shadow-lg"
            >
              {mode === 'LOGIN' ? 'Join the Garden' : 'Return to Login'}
            </button>
          </div>
        </div>

        <div className="mt-10 text-center pb-10 md:pb-0">
          <p className="text-slate-600 text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2">
            <Sparkles className="w-3 h-3 text-emerald-500" />
            End-to-End Local Data Isolation Active
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthView;
