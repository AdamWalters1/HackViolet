
export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; // Stored locally for simulation
  avatar: string;
}

export interface PlantCondition {
  timestamp: number;
  moisture: number; // 0-100
  temperature: number; // °C
  light: number; // 0-100
}

export interface PlantTargets {
  moisture: number; // Ideal %
  temperature: number; // Ideal °C
  light: number; // Ideal % intensity
  dailyWaterLitres: number; // Ideal daily volume
  dailyLightHours: number; // Ideal hours of light
}

export interface Plant {
  id: string;
  name: string;
  species: string;
  description?: string; // Added to store AI-enriched bios
  image: string;
  addedAt: number;
  conditions: PlantCondition[];
  targets?: PlantTargets;
}

export interface DiagnosisResult {
  mood: 'Happy' | 'Neutral' | 'Unhappy';
  water_now: boolean;
  seconds: number;
  reason: string;
  confidence: number;
}

export interface AppSettings {
  keeperName: string;
  tempUnit: 'C' | 'F';
  darkMode: boolean;
  notifications: {
    moistureAlerts: boolean;
    tempAlerts: boolean;
    lightAlerts: boolean;
  };
  syncInterval: number; // in minutes
}

export type AIChatType = 'FAST' | 'THINKING' | 'SEARCH' | 'MAPS';

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  content: string;
  type?: AIChatType;
  groundingUrls?: { title: string; uri: string }[];
}
